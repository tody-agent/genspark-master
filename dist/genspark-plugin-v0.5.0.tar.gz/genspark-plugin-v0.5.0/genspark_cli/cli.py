"""Click CLI entrypoint for Genspark CLI.

Usage:
    genspark auth login          — Login via browser (one-time, default profile)
    genspark auth add <name>     — Add a new account profile
    genspark auth list           — List all account profiles
    genspark auth switch <name>  — Set default profile
    genspark auth refresh [name] — Re-login to refresh a profile's token
    genspark auth status         — Check session health (all profiles)
    genspark auth logout         — Clear session for a profile
    genspark chat ask "prompt"   — Send a message (fast httpx)
    genspark chat                — Interactive REPL mode
    genspark models list         — List available models
    genspark session list        — List recent conversations
    genspark session info <id>   — Show conversation details
    genspark session delete <id> — Delete a conversation
    genspark server start        — Start OpenAI-compatible proxy
    genspark integrate 9router   — Show 9Router configuration
"""

import json
import os
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.markdown import Markdown

from . import __version__
from .capabilities import capabilities_document
from .doctor import run_doctor
from .exceptions import GensparkError
from .log import log, set_level
from .models import DEFAULT_MODEL, list_models, resolve_model, MODELS
from .profiles import ProfileManager
from .session import SessionManager


console = Console()


def get_profile_manager() -> ProfileManager:
    """Get or create profile manager."""
    return ProfileManager()


def get_session(profile: str | None = None) -> SessionManager:
    """Get session for a specific or default profile."""
    pm = get_profile_manager()
    return pm.get_session(profile)


# ── Main Group (Claude Code / Hermes Style Ergonomics) ──────────────────

class GensparkGroup(click.Group):
    """Custom Click Group supporting zero-friction shorthand prompts (`gsk "prompt"`)."""

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and not any(flag in args for flag in ("-h", "--help", "--version")):
            # Top-level image shorthand: `gsk -i "prompt"` or `gsk --image "prompt"`
            if args[0] in ("-i", "--image"):
                rewritten = ["image", "generate", *args[1:]]
                return super().parse_args(ctx, rewritten)

            # Find first positional token after top-level flags (-v/-q)
            idx = 0
            while idx < len(args) and args[idx] in ("-v", "--verbose", "-q", "--quiet"):
                idx += 1

            if idx < len(args):
                first_token = args[idx]
                if not first_token.startswith("-") and first_token not in self.commands:
                    rewritten = [*args[:idx], "run", *args[idx:]]
                    return super().parse_args(ctx, rewritten)

        return super().parse_args(ctx, args)


@click.group(cls=GensparkGroup, invoke_without_command=True)
@click.version_option(version=__version__, prog_name="genspark")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging (DEBUG)")
@click.option("--quiet", "-q", is_flag=True, help="Suppress all non-error output")
@click.pass_context
def main(ctx, verbose, quiet):
    """⚡ Genspark Agentic CLI — Multi-Account AI Gateway & Studio (gsk)

    Access Claude Opus 5.5, GPT-6 Sol, Gemini 3.8, DeepSeek V4.1, and 7 image
    models with automatic multi-account round-robin routing and failover.

    \b
    Agentic Shorthands (Claude Code / Hermes style):
      gsk                           # Launch Interactive Agentic Studio REPL
      gsk "Explain this code"       # Instant one-shot prompt across account pool
      gsk -i "A cyberpunk street"   # Instant image generation across account pool
      gsk pool                      # View multi-account pool health & stats
      gsk batch tasks.jsonl -c 6    # Run parallel batch across all accounts
      gsk config                    # Configure default model, strategy & concurrency
    """
    if verbose:
        set_level("DEBUG")
    elif quiet:
        set_level("ERROR")

    if ctx.invoked_subcommand is None:
        if sys.stdin.isatty() and sys.stdout.isatty() and not os.environ.get("PYTEST_CURRENT_TEST"):
            from .menu import home_menu

            home_menu(get_profile_manager())
        else:
            click.echo(ctx.get_help())


@main.command(name="menu")
def menu_cmd():
    """📋 Open the interactive home menu."""
    from .menu import home_menu

    home_menu(get_profile_manager())


@main.command(name="accounts")
def accounts_cmd():
    """👥 Interactive account manager (add / login / logout / remove)."""
    from .menu import accounts_menu

    accounts_menu(get_profile_manager())


@main.command(name="setup")
def setup_cmd():
    """✨ Run the first-time guided onboarding."""
    from .menu import onboarding

    onboarding(get_profile_manager())


@main.command()
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
def capabilities(as_json):
    """List supported local interfaces and their authentication contract."""
    payload = capabilities_document()
    if as_json:
        click.echo(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return

    table = Table(title="Genspark capabilities")
    table.add_column("ID", style="cyan")
    table.add_column("Interface")
    table.add_column("Authentication")
    table.add_column("Command")
    for item in payload["capabilities"]:
        table.add_row(
            item["id"],
            item["interface"],
            item["authentication"],
            item["command"],
        )
    console.print(table)


@main.command()
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
def doctor(as_json):
    """Check installation and browser-login state without network access."""
    try:
        payload = run_doctor()
    except Exception as exc:
        error = {
            "schema_version": 1,
            "status": "error",
            "error": {"type": type(exc).__name__, "message": str(exc)},
        }
        if as_json:
            click.echo(json.dumps(error, ensure_ascii=False, sort_keys=True))
            click.echo(f"Doctor failed: {exc}", err=True)
        else:
            console.print(f"[red]Doctor failed:[/] {exc}")
        raise click.exceptions.Exit(1) from exc

    if as_json:
        click.echo(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return

    color = {"ok": "green", "degraded": "yellow", "error": "red"}[payload["status"]]
    console.print(f"Doctor status: [{color}]{payload['status']}[/]")
    for name, check in payload["checks"].items():
        console.print(f"  {name}: {check['status']}")


# ── Auth Commands ────────────────────────────────────────────────────────

@main.group()
def auth():
    """🔐 Authentication & account management."""
    pass


@auth.command()
@click.option("--profile", "-p", default=None, help="Profile name to login (default profile if omitted)")
def login(profile):
    """Open browser to login to Genspark.

    Saves session cookies locally. All future chat uses fast HTTP.
    """
    from .auth import run_login

    pm = get_profile_manager()
    profile_name = profile or pm.default_profile

    try:
        session = pm.get_session(profile_name)
    except ValueError:
        # Profile doesn't exist, create it
        session = pm.add_profile(profile_name)

    if session.is_logged_in:
        health = session.check_cookie_health()
        if health == "fresh":
            if not click.confirm(
                f"Profile '{profile_name}' is already logged in (cookies fresh). Re-login?",
                default=False,
            ):
                console.print(f"[green]✓[/] Already logged in as [cyan]{profile_name}[/].")
                return
        else:
            console.print(f"[yellow]Profile '{profile_name}' cookie status: {health}[/] — refreshing...")

    console.print(Panel(
        f"[bold]🌐 Opening browser for login...[/]\n"
        f"Profile: [cyan]{profile_name}[/]\n\n"
        "1. Log in with your Google/email account\n"
        "2. Wait for the chat page to load\n"
        "3. Send ANY message in the chat\n"
        "4. Come back here and press Enter",
        title="Login",
        border_style="blue",
    ))

    try:
        success = run_login(session)
        if success:
            console.print(f"\n[bold green]✅ Session saved![/] Profile: [cyan]{profile_name}[/]")
            console.print("[dim]   All chat is via fast HTTP — no browser needed.[/]")
        else:
            console.print("\n[yellow]⚠️ Login may not have completed. Try again.[/]")
    except GensparkError as e:
        console.print(f"\n[red]Login failed:[/] {e}")
        sys.exit(1)


@auth.command()
@click.argument("name")
def add(name):
    """Add a new account profile and login.

    Creates a new named profile and opens browser for login.

    \b
    Examples:
      genspark auth add work
      genspark auth add backup-account
    """
    from .auth import run_login

    pm = get_profile_manager()

    try:
        session = pm.add_profile(name)
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/] Created profile [cyan]{name}[/]")
    console.print(Panel(
        f"[bold]🌐 Opening browser to login profile '{name}'...[/]\n\n"
        "1. Log in with a DIFFERENT Google/email account\n"
        "2. Wait for the chat page to load\n"
        "3. Send ANY message in the chat\n"
        "4. Come back here and press Enter",
        title=f"Login — {name}",
        border_style="blue",
    ))

    try:
        success = run_login(session)
        if success:
            console.print(f"\n[bold green]✅ Profile '{name}' ready![/]")
            console.print(f"[dim]   Switch to it: genspark auth switch {name}[/]")
        else:
            console.print("\n[yellow]⚠️ Login may not have completed. Try again.[/]")
    except GensparkError as e:
        console.print(f"\n[red]Login failed:[/] {e}")
        sys.exit(1)


@auth.command(name="list")
def auth_list():
    """List all account profiles with health status."""
    pm = get_profile_manager()
    profiles = pm.list_profiles()

    if not profiles:
        console.print("[yellow]No profiles found.[/] Run [cyan]genspark auth login[/] to create one.")
        return

    table = Table(
        title="🔐 Account Profiles",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("Name", style="green")
    table.add_column("Default", style="yellow", justify="center")
    table.add_column("Logged In", justify="center")
    table.add_column("Cookie Health", justify="center")
    table.add_column("Age")

    for p in profiles:
        default_marker = "★" if p["is_default"] else ""
        logged_in = "[green]✓[/]" if p["is_logged_in"] else "[red]✗[/]"

        health = p["cookie_health"]
        health_colors = {"fresh": "green", "aging": "yellow", "expired": "red", "missing": "red"}
        color = health_colors.get(health, "white")
        health_str = f"[{color}]{health}[/]"

        age_str = ""
        if p["cookie_age"] is not None:
            days = int(p["cookie_age"] / 86400)
            if days > 0:
                age_str = f"{days}d"
            else:
                hours = int(p["cookie_age"] / 3600)
                age_str = f"{hours}h"

        table.add_row(p["name"], default_marker, logged_in, health_str, age_str)

    console.print(table)
    console.print(f"\n[dim]★ = default profile. Switch with: genspark auth switch <name>[/]")


@auth.command()
@click.argument("name")
def switch(name):
    """Set the default account profile.

    \b
    Example:
      genspark auth switch work
    """
    pm = get_profile_manager()
    try:
        pm.default_profile = name
        console.print(f"[green]✓[/] Default profile set to [cyan]{name}[/]")
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)


@auth.command()
@click.argument("name", required=False)
def refresh(name):
    """Re-login to refresh tokens for a profile.

    Without arguments, refreshes the default profile.
    """
    from .auth import run_login

    pm = get_profile_manager()
    profile_name = name or pm.default_profile

    try:
        session = pm.get_session(profile_name)
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)

    console.print(f"[bold]Refreshing profile [cyan]{profile_name}[/]...[/]")
    console.print(Panel(
        "🌐 Opening browser for re-login...\n\n"
        "1. Log in (if needed)\n"
        "2. Send ANY message in the chat\n"
        "3. Press Enter here when done",
        title=f"Refresh — {profile_name}",
        border_style="yellow",
    ))

    try:
        success = run_login(session)
        if success:
            console.print(f"\n[bold green]✅ Profile '{profile_name}' refreshed![/]")
        else:
            console.print("\n[yellow]⚠️ Refresh may not have completed.[/]")
    except GensparkError as e:
        console.print(f"\n[red]Refresh failed:[/] {e}")
        sys.exit(1)


@auth.command()
def status():
    """Check login status and cookie health for all profiles."""
    pm = get_profile_manager()
    profiles = pm.list_profiles()

    if not profiles:
        console.print("[yellow]No profiles.[/] Run [cyan]genspark auth login[/]")
        return

    for p in profiles:
        name = p["name"]
        is_default = p["is_default"]
        marker = " [yellow]★ default[/]" if is_default else ""

        if p["is_logged_in"]:
            health = p["cookie_health"]
            health_colors = {"fresh": "green", "aging": "yellow", "expired": "red"}
            color = health_colors.get(health, "white")

            age_str = ""
            if p["cookie_age"] is not None:
                days = int(p["cookie_age"] / 86400)
                age_str = f" ({days}d old)" if days > 0 else " (fresh)"

            console.print(f"[green]✓[/] [bold]{name}[/]{marker}")
            console.print(f"    Cookie health: [{color}]{health}{age_str}[/]")

            session = pm.get_session(name)
            cookies = session.get_cookies_dict()
            console.print(f"    Cookies: {len(cookies)}")

            token = session.get_recaptcha_token()
            if token:
                token_age = session.get_recaptcha_token_age()
                if token_age is not None:
                    hours = int(token_age / 3600)
                    age_label = f"{hours}h old" if hours > 0 else f"{int(token_age / 60)}m old"
                else:
                    age_label = "age unknown"
                console.print(f"    reCAPTCHA: [green]✓[/] ({age_label})")
            else:
                console.print(f"    reCAPTCHA: [red]✗ missing[/]")
        else:
            console.print(f"[red]✗[/] [bold]{name}[/]{marker} — not logged in")

        console.print()


@auth.command()
@click.argument("name", required=False)
@click.option("--force", "-f", is_flag=True, help="Skip confirmation")
def logout(name, force):
    """Clear saved session for a profile.

    Without arguments, clears the default profile.
    """
    pm = get_profile_manager()
    profile_name = name or pm.default_profile

    try:
        session = pm.get_session(profile_name)
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)

    if not force:
        if not click.confirm(f"Clear session for profile '{profile_name}'?", default=False):
            console.print("[dim]Cancelled.[/]")
            return

    session.clear()
    console.print(f"[green]✓[/] Session cleared for [cyan]{profile_name}[/].")


@auth.command()
@click.argument("name")
@click.option("--force", "-f", is_flag=True, help="Skip confirmation")
def remove(name, force):
    """Delete an account profile completely."""
    pm = get_profile_manager()

    if not force:
        if not click.confirm(f"Delete profile '{name}' and all its data?", default=False):
            console.print("[dim]Cancelled.[/]")
            return

    try:
        pm.remove_profile(name)
        console.print(f"[green]✓[/] Profile [cyan]{name}[/] deleted.")
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)


# ── Chat Commands ────────────────────────────────────────────────────────

@main.group(invoke_without_command=True)
@click.option("--profile", "-p", default=None, help="Account profile to use")
@click.pass_context
def chat(ctx, profile):
    """💬 Chat with AI models.

    \b
    Run without a subcommand for interactive mode:
      genspark chat
      genspark chat -p work    # use 'work' profile

    \b
    Or use 'ask' for a single query:
      genspark chat ask "What is AI?"
    """
    ctx.ensure_object(dict)
    ctx.obj["profile"] = profile

    if ctx.invoked_subcommand is None:
        # Interactive mode
        from .interactive import run_interactive
        pm = get_profile_manager()

        try:
            from .account_router import AccountRouter
            router = AccountRouter(pm)
            session = router.get_session(preferred=profile)
            profile_name = session.profile_name
        except RuntimeError as e:
            console.print(f"[red]Error:[/] {e}")
            sys.exit(1)

        run_interactive(
            session,
            model=DEFAULT_MODEL,
            profile_manager=pm,
            profile_name=profile_name,
        )


@chat.command()
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_MODEL,
              help=f"Model to use (default: {DEFAULT_MODEL})")
@click.option("--stream", "-s", is_flag=True, default=False,
              help="Stream response in real-time")
@click.option("--json-output", "--json", "json_out", is_flag=True, default=False,
              help="Output as JSON (OpenAI-compatible format)")
@click.option("--raw", is_flag=True, default=False,
              help="Output raw text without formatting")
@click.option("--profile", "-p", default=None, help="Account profile to use")
@click.pass_context
def ask(ctx, prompt, model, stream, json_out, raw, profile):
    """Send a message to the AI and get a response.

    Uses fast HTTP (no browser). Requires prior login via 'genspark auth login'.

    \b
    Examples:
      genspark chat ask "What is quantum computing?"
      genspark chat ask "Write a Python function" --model gpt-5.4
      genspark chat ask "Explain AI" --stream -p work
      genspark chat ask "Hello" --json
    """
    from .client import run_chat
    from .account_router import AccountRouter

    # Use profile from parent group or this option
    profile = profile or (ctx.parent.obj or {}).get("profile")

    pm = get_profile_manager()
    router = AccountRouter(pm)
    if router.pool_size == 0:
        console.print("[red]Error:[/] No accounts configured. Run: genspark auth login")
        sys.exit(1)

    # Resolve model name
    try:
        model_info = resolve_model(model)
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)

    def _on_failover(failed_prof: str, reason: str, _exc: Exception) -> None:
        if not json_out and not raw:
            console.print(
                f"[yellow]↻ Account '{failed_prof}' unavailable ({reason}) — failing over to next account...[/]"
            )

    def _do_ask(active_session: SessionManager):
        if not json_out and not raw:
            profile_label = f" [dim]({active_session.profile_name})[/]"
            console.print(f"[dim]Using model: {model_info.display_name}{profile_label}[/]")
            health = active_session.check_cookie_health()
            if health == "missing":
                console.print("[red]⚠ No session found.[/] Run [cyan]genspark auth login[/] first.")
                sys.exit(1)
            elif health == "expired":
                console.print("[yellow]⚠ Cookies may be expired.[/] Run [cyan]genspark auth login[/] to refresh.")
            console.print()
        return run_chat(
            session=active_session,
            prompt=prompt,
            model=model_info.id,
            stream=stream,
        )

    try:
        result = router.run_with_failover(
            _do_ask,
            preferred=profile,
            on_failover=_on_failover,
        )

        if json_out:
            output = result.to_openai_format()
            click.echo(json.dumps(output, indent=2, ensure_ascii=False))
        elif raw:
            click.echo(result.content)
        else:
            if not stream:  # Stream already printed chunks
                if result.content:
                    console.print(Panel(
                        Markdown(result.content),
                        title=f"[bold]{model_info.display_name}[/]",
                        border_style="green",
                        padding=(1, 2),
                    ))
                else:
                    console.print("[yellow]No response received.[/]")
                    console.print("[dim]Try: genspark auth login  (to refresh session)[/]")

    except GensparkError as e:
        console.print(f"[red]Error:[/] {e}")
        log.error("Chat error: %s", e, exc_info=True)
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error:[/] {e}")
        log.error("Unexpected chat error: %s", e, exc_info=True)
        if not json_out:
            console.print("[dim]Check logs: ~/.genspark/genspark.log[/]")
        sys.exit(1)



# ── Run Command ──────────────────────────────────────────────────────────

def _extract_and_execute_code(content: str, raw: bool = False) -> int:
    """Extract code blocks from AI response and execute them locally."""
    import re
    import subprocess
    import time

    # Match fenced code blocks with language
    code_blocks = re.findall(r"```([a-zA-Z0-9_\-+]*)\n(.*?)```", content, re.DOTALL)
    if not code_blocks:
        if not raw:
            console.print("[yellow]⚠ No executable code blocks found in the response.[/]")
        return 0

    overall_exit_code = 0
    for idx, (lang, code) in enumerate(code_blocks, 1):
        lang = (lang or "bash").strip().lower()
        if lang in ("python", "python3", "py"):
            exec_lang = "python"
        elif lang in ("bash", "sh", "zsh"):
            exec_lang = "bash"
        else:
            # Skip non-executable languages like markdown, json, yaml, etc.
            continue

        code_to_run = code.strip()
        if not code_to_run:
            continue

        if not raw:
            preview = code_to_run[:200] + ("..." if len(code_to_run) > 200 else "")
            console.print(Panel(
                f"[bold cyan]⚡ Running Code Block #{idx} ({exec_lang.upper()})[/]\n"
                f"[dim]{preview}[/]",
                border_style="cyan"
            ))

        start_time = time.time()
        try:
            if exec_lang == "python":
                cmd = [sys.executable, "-c", code_to_run]
            else:
                cmd = ["bash", "-c", code_to_run]

            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
            )
            elapsed = time.time() - start_time

            if proc.stdout:
                if raw:
                    sys.stdout.write(proc.stdout)
                else:
                    console.print(Panel(proc.stdout.rstrip(), title="[green]STDOUT[/]", border_style="green"))
            if proc.stderr:
                if raw:
                    sys.stderr.write(proc.stderr)
                else:
                    console.print(Panel(proc.stderr.rstrip(), title="[red]STDERR[/]", border_style="red"))

            if not raw:
                status_color = "green" if proc.returncode == 0 else "red"
                console.print(f"[{status_color}]✓ Block #{idx} finished with exit code {proc.returncode} ({elapsed:.2f}s)[/]\n")

            if proc.returncode != 0:
                overall_exit_code = proc.returncode
        except subprocess.TimeoutExpired:
            if not raw:
                console.print(f"[red]❌ Execution of Block #{idx} timed out after 120s[/]")
            overall_exit_code = 124
        except Exception as e:
            if not raw:
                console.print(f"[red]❌ Execution error on Block #{idx}: {e}[/]")
            overall_exit_code = 1

    return overall_exit_code


@main.command(name="run")
@click.argument("prompt", required=False, default=None)
@click.option("--file", "-f", "files", multiple=True, type=click.Path(exists=True),
              help="File(s) to include as context")
@click.option("--model", "-m", default=DEFAULT_MODEL,
              help=f"Model to use (default: {DEFAULT_MODEL})")
@click.option("--stream/--no-stream", default=True,
              help="Stream response in real-time (default: True)")
@click.option("--exec", "-x", "execute_code", is_flag=True, default=False,
              help="Extract and execute generated code blocks locally (python/bash)")
@click.option("--raw", "-r", is_flag=True, default=False,
              help="Output raw text without formatting (ideal for piping)")
@click.option("--json", "json_out", is_flag=True, default=False,
              help="Output response as OpenAI-compatible JSON")
@click.option("--system", "-s", "system_prompt", default=None,
              help="Optional system prompt / instructions")
@click.option("--profile", "-p", default=None,
              help="Account profile to use")
@click.option("--server", is_flag=True, default=False,
              help="Shortcut: Start OpenAI API proxy server")
@click.option("--mcp", "run_mcp", is_flag=True, default=False,
              help="Shortcut: Start stdio MCP server")
@click.pass_context
def run_command(ctx, prompt, files, model, stream, execute_code, raw, json_out, system_prompt, profile, server, run_mcp):
    """⚡ Fast AI Runner — Execute prompts, pipes, files, code & servers.

    \b
    Examples:
      # Direct prompt execution
      genspark run "Write a quick Python script to check internet connection"
      
      # Pipe input from stdin
      git diff | genspark run "Review these code changes"
      cat logs.txt | genspark run "Explain this error stack trace" -r
      
      # Include files as context
      genspark run -f main.py "Refactor this code cleanly"
      genspark run -f schema.sql "Generate Pydantic models for this schema"
      
      # Autonomous Code Runner (extracts and executes AI code locally)
      genspark run -x "Write a python script to calculate sha256 of pyproject.toml"
      genspark run -x "List all git branches sorted by last commit date"
      
      # Shortcuts for servers
      genspark run server
      genspark run mcp
    """
    # 1. Handle shortcuts: server / mcp
    if server or prompt == "server":
        ctx.invoke(start)
        return
    if run_mcp or prompt == "mcp":
        from .mcp import run_mcp_server
        run_mcp_server()
        return

    # 2. Gather prompt from args or STDIN
    stdin_content = ""
    if not sys.stdin.isatty():
        try:
            stdin_content = sys.stdin.read()
        except Exception:
            pass

    full_prompt_parts = []
    if system_prompt:
        full_prompt_parts.append(f"[System Instruction]\n{system_prompt}\n")

    # Add file contexts
    if files:
        for fpath in files:
            p = Path(fpath)
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
                full_prompt_parts.append(f"--- File: {p.name} ---\n{content}\n")
            except Exception as e:
                console.print(f"[yellow]Warning: Could not read file {fpath}: {e}[/]")

    if stdin_content:
        full_prompt_parts.append(f"--- Standard Input ---\n{stdin_content}\n")

    if prompt:
        full_prompt_parts.append(prompt)

    if not full_prompt_parts:
        console.print("[red]Error:[/] No prompt provided. Provide a prompt argument, pipe via stdin, or run [cyan]genspark run --help[/]")
        sys.exit(1)

    final_prompt = "\n\n".join(full_prompt_parts).strip()

    # 3. Setup Session & Model with Multi-Account Auto-Failover
    from .client import run_chat
    from .account_router import AccountRouter

    pm = get_profile_manager()
    router = AccountRouter(pm)

    try:
        model_info = resolve_model(model)
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)

    def _on_run_failover(failed_prof: str, reason: str, _exc: Exception) -> None:
        if not json_out and not raw:
            console.print(
                f"[yellow]↻ Account '{failed_prof}' unavailable ({reason}) — failing over to next account...[/]"
            )

    def _do_run(active_session: SessionManager):
        if not json_out and not raw:
            profile_label = f" [dim]({active_session.profile_name})[/]"
            console.print(f"[dim]⚡ Running with {model_info.display_name}{profile_label}...[/]")
        return run_chat(
            session=active_session,
            prompt=final_prompt,
            model=model_info.id,
            stream=stream and not json_out and not raw and not execute_code,
        )

    try:
        result = router.run_with_failover(
            _do_run,
            preferred=profile,
            on_failover=_on_run_failover,
        )

        if json_out:
            output = result.to_openai_format()
            click.echo(json.dumps(output, indent=2, ensure_ascii=False))
        elif raw:
            click.echo(result.content)
        else:
            if not stream or execute_code:
                if result.content:
                    console.print(Panel(
                        Markdown(result.content),
                        title=f"[bold]{model_info.display_name}[/]",
                        border_style="green",
                        padding=(1, 2),
                    ))
                else:
                    console.print("[yellow]No response received.[/]")

        # 4. If --exec was passed, execute code blocks
        if execute_code and result.content:
            exit_code = _extract_and_execute_code(result.content, raw=raw)
            if exit_code != 0:
                sys.exit(exit_code)

    except GensparkError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error:[/] {e}")
        sys.exit(1)


# ── Session Commands ─────────────────────────────────────────────────────


@main.group()
def session():
    """📝 Manage conversation sessions."""
    pass


@session.command(name="list")
@click.option("--limit", "-n", default=10, help="Number of conversations to show")
def session_list(limit):
    """List recent conversations.

    \b
    Examples:
      genspark session list
      genspark session list -n 20
    """
    from .conversations import ConversationStore

    store = ConversationStore()
    conversations = store.list_recent(limit=limit)

    if not conversations:
        console.print("[dim]No conversations yet.[/] Start chatting with [cyan]genspark chat[/]")
        return

    table = Table(
        title="📝 Recent Conversations",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("ID", style="dim", max_width=12)
    table.add_column("Name", style="white", max_width=50)
    table.add_column("Model", style="blue")
    table.add_column("Turns", justify="right", style="yellow")
    table.add_column("Profile", style="green")
    table.add_column("Last Active", style="dim")

    import time as _time
    now = _time.time()

    for c in conversations:
        cid = c.get("id", "")[:12]
        display = c.get("display_name", c.get("name", "unnamed"))
        if len(display) > 50:
            display = display[:47] + "..."
        model_name = c.get("model", "")
        turns = str(c.get("turn_count", 0))
        profile_name = c.get("profile", "default")

        last_active = c.get("last_active", 0)
        if last_active:
            age = now - last_active
            if age < 3600:
                age_str = f"{int(age / 60)}m ago"
            elif age < 86400:
                age_str = f"{int(age / 3600)}h ago"
            else:
                age_str = f"{int(age / 86400)}d ago"
        else:
            age_str = ""

        has_summary = "📋" if c.get("has_summary") else ""
        table.add_row(cid, f"{display} {has_summary}", model_name, turns, profile_name, age_str)

    console.print(table)
    console.print(f"\n[dim]Total: {store.count} conversations. 📋 = has summary[/]")


@session.command()
@click.argument("conv_id")
def info(conv_id):
    """Show details about a conversation."""
    from .conversations import ConversationStore
    from .context_manager import ContextManager

    store = ConversationStore()

    # Support partial ID matching
    conv = store.get(conv_id)
    if not conv:
        # Try partial match from index
        for entry in store.list_all():
            if entry.get("id", "").startswith(conv_id):
                conv = store.get(entry["id"])
                break

    if not conv:
        console.print(f"[red]Conversation not found:[/] {conv_id}")
        sys.exit(1)

    ctx_mgr = ContextManager()
    console.print(Panel(
        ctx_mgr.format_context_info(conv),
        title=f"Session: {conv.display_name}",
        border_style="blue",
    ))

    # Show last few messages
    recent = conv.messages[-6:] if len(conv.messages) > 6 else conv.messages
    if recent:
        console.print("\n[bold]Recent messages:[/]")
        for msg in recent:
            role_color = "green" if msg.role == "user" else "cyan"
            preview = msg.content[:200]
            if len(msg.content) > 200:
                preview += "..."
            console.print(f"  [{role_color}]{msg.role}:[/] {preview}")


@session.command()
@click.argument("conv_id")
@click.option("--force", "-f", is_flag=True, help="Skip confirmation")
def delete(conv_id, force):
    """Delete a conversation."""
    from .conversations import ConversationStore

    store = ConversationStore()

    if not force:
        if not click.confirm(f"Delete conversation {conv_id}?", default=False):
            console.print("[dim]Cancelled.[/]")
            return

    # Support partial ID matching
    full_id = conv_id
    for entry in store.list_all():
        if entry.get("id", "").startswith(conv_id):
            full_id = entry["id"]
            break

    if store.delete(full_id):
        console.print(f"[green]✓[/] Conversation deleted.")
    else:
        console.print(f"[red]Conversation not found:[/] {conv_id}")


# ── Models Commands ──────────────────────────────────────────────────────

@main.group()
def models():
    """📋 List and inspect available models."""
    pass


@models.command(name="list")
@click.option("--tier", type=click.Choice(["premium", "fast", "special"]),
              help="Filter by model tier")
@click.option("--provider", type=click.Choice(["openai", "anthropic", "google", "xai"]),
              help="Filter by provider")
@click.option("--json-output", "--json", "json_out", is_flag=True,
              help="Output as JSON")
def list_cmd(tier, provider, json_out):
    """List all available AI models.

    \b
    Examples:
      genspark models list
      genspark models list --tier premium
      genspark models list --provider anthropic --json
    """
    models_list = list_models(tier=tier, provider=provider)

    if json_out:
        output = [
            {
                "id": m.id,
                "name": m.display_name,
                "provider": m.provider,
                "tier": m.tier,
                "multiplier": m.multiplier,
                "recommended": m.is_recommended,
            }
            for m in models_list
        ]
        click.echo(json.dumps(output, indent=2))
        return

    table = Table(
        title="🤖 Available Genspark AI Models",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("ID", style="green")
    table.add_column("Name", style="white")
    table.add_column("Provider", style="blue")
    table.add_column("Tier", style="yellow")
    table.add_column("Multiplier", style="magenta")

    default_id = DEFAULT_MODEL
    for m in models_list:
        marker = " ★" if m.id == default_id else (" 🔥" if m.is_recommended else "")
        mult_str = f"{m.multiplier}×"
        table.add_row(m.id, m.display_name + marker, m.provider, m.tier, mult_str)

    console.print(table)
    console.print(f"\n[dim]★ = default model ({DEFAULT_MODEL}). 🔥 = recommended. Override with --model <id>[/]")
    console.print(f"[dim]Total: {len(models_list)} models available[/]")


# ── Server Command ───────────────────────────────────────────────────────

@main.group()
def server():
    """🖥️ OpenAI-compatible API proxy server."""
    pass


@server.command()
@click.option("--port", "-p", default=8080, help="Port to listen on")
@click.option("--host", default="127.0.0.1", help="Host to bind to")
@click.option("--model", "-m", default=DEFAULT_MODEL, help="Default model")
def start(port, host, model):
    """Start the OpenAI-compatible proxy server.

    Exposes Genspark AI Chat as an OpenAI-compatible REST API
    at http://localhost:8080/v1/chat/completions

    Uses fast HTTP with multi-account failover.

    \b
    Use with any OpenAI-compatible client:
      export OPENAI_API_BASE=http://localhost:8080/v1
      export OPENAI_API_KEY=dummy
    """
    pm = get_profile_manager()
    healthy = pm.get_healthy_profiles()

    console.print(Panel(
        f"[bold]🖥️ Starting OpenAI-compatible proxy server[/]\n\n"
        f"  Endpoint: [cyan]http://{host}:{port}/v1/chat/completions[/]\n"
        f"  Default model: [green]{model}[/]\n"
        f"  Backend: [green]httpx (multi-account failover)[/]\n"
        f"  Accounts: [green]{len(healthy)}[/] healthy profiles\n\n"
        f"  [dim]Set OPENAI_API_BASE=http://{host}:{port}/v1 in your client[/]",
        title="Server",
        border_style="blue",
    ))

    from .server import run_server
    run_server(host=host, port=port, default_model=model)


@server.command(name="run")
@click.option("--port", "-p", default=8080, help="Port to listen on")
@click.option("--host", default="127.0.0.1", help="Host to bind to")
@click.option("--model", "-m", default=DEFAULT_MODEL, help="Default model")
@click.pass_context
def server_run(ctx, port, host, model):
    """Run the OpenAI-compatible proxy server (alias to start)."""
    ctx.invoke(start, port=port, host=host, model=model)


# ── MCP Commands ─────────────────────────────────────────────────────────

@main.group()
def mcp():
    """🤖 MCP Server for AI agent integration."""
    pass


@mcp.command(name="start")
def mcp_start():
    """Start the Genspark stdio MCP server directly."""
    from .mcp import run_mcp_server
    run_mcp_server()


@mcp.command(name="run")
def mcp_run():
    """Run the Genspark stdio MCP server directly."""
    from .mcp import run_mcp_server
    run_mcp_server()


@mcp.command()
def info():

    """Show MCP configuration for various AI agents.

    Displays ready-to-use config for Claude Code, Gemini CLI,
    Cursor, OpenClaw, and other MCP-compatible agents.
    """
    import shutil

    # Find genspark-mcp binary
    mcp_bin = shutil.which("genspark-mcp")
    mcp_cmd = mcp_bin or "genspark-mcp"

    console.print(Panel(
        "[bold cyan]MCP Server Configuration[/]\n\n"
        "[bold]Claude Code:[/]\n"
        f"  [green]claude mcp add genspark -- {mcp_cmd}[/]\n\n"
        "[bold]Gemini CLI:[/]\n"
        f"  [green]gemini mcp add genspark {mcp_cmd}[/]\n\n"
        "[bold]Cursor / OpenClaw / Cline (JSON config):[/]\n"
        f'  [green]{{"mcpServers": {{"genspark": {{"command": "{mcp_cmd}"}}}}}}[/]\n\n'
        "[bold]Available MCP Tools (9):[/]\n"
        "  • [cyan]chat[/]                  — Send message to any AI model (with auto-failover)\n"
        "  • [cyan]chat_with_context[/]     — Chat with a system prompt\n"
        "  • [cyan]batch_chat[/]            — Run multiple prompts concurrently across account pool\n"
        "  • [cyan]generate_image[/]        — Generate images with 7 free models\n"
        "  • [cyan]batch_generate_images[/] — Generate multiple images concurrently across pool\n"
        "  • [cyan]configure_pool[/]        — Inspect/update routing strategy & reset cooldowns\n"
        "  • [cyan]get_models[/]            — List 32+ free AI chat models\n"
        "  • [cyan]list_image_models[/]     — List 7 free image models\n"
        "  • [cyan]check_status[/]          — Check multi-account session & pool health",
        title="MCP Server",
        border_style="blue",
    ))


# ── Image Commands ───────────────────────────────────────────────────────

@main.group()
def image():
    """🎨 AI Image generation (FREE).

    Generate images using 7 free AI models including Flux 2, Nano Banana,
    GPT Image, and more. Supports 170+ art styles and 14 aspect ratios.

    \b
    Quick start:
      genspark image generate "a cyberpunk city at night"
      genspark image generate "portrait" --style "Oil Painting" --ratio 3:4
      genspark image models
      genspark image styles --search "cyber"
    """
    pass


@image.command()
@click.argument("prompt")
@click.option("--model", "-m", default=None,
              help="Image model to use (default: nano-banana-2)")
@click.option("--style", "-s", default="auto",
              help="Art style (e.g., 'Cyberpunk', 'Oil Painting', 'Anime 3D Game Look')")
@click.option("--ratio", "-r", default="auto",
              help="Aspect ratio (e.g., 16:9, 1:1, 3:4, 9:16)")
@click.option("--size", default="auto",
              help="Image size (auto, 0.5K, 1K, 2K, 4K)")
@click.option("--output", "-o", default=None,
              help="Output directory (default: current directory)")
@click.option("--no-download", is_flag=True, default=False,
              help="Don't download — just print URL")
@click.option("--no-enhance", is_flag=True, default=False,
              help="Don't auto-enhance the prompt")
@click.option("--profile", "-p", default=None, help="Account profile to use")
@click.option("--json-output", "--json", "json_out", is_flag=True, default=False,
              help="Output as JSON")
def generate(prompt, model, style, ratio, size, output, no_download, no_enhance, profile, json_out):
    """Generate an image from a text prompt.

    Uses the same authentication as chat — requires prior login.

    \b
    Examples:
      genspark image generate "a cat wearing a spacesuit"
      genspark image generate "sunset over ocean" --model flux-2-pro --size 4K
      genspark image generate "portrait" --style "Oil Painting" --ratio 3:4
      genspark image generate "logo" --no-download --json
    """
    from .image_client import run_image_generate
    from .image_models import DEFAULT_IMAGE_MODEL, resolve_image_model
    from .account_router import AccountRouter

    pm = get_profile_manager()
    router = AccountRouter(pm)

    # Resolve model
    model_id = model or pm.default_image_model or DEFAULT_IMAGE_MODEL
    try:
        model_info = resolve_image_model(model_id)
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)

    def _on_img_failover(failed_prof: str, reason: str, _exc: Exception) -> None:
        if not json_out:
            console.print(
                f"[yellow]↻ Account '{failed_prof}' unavailable ({reason}) — failing over to next account...[/]"
            )

    def _do_generate(active_session: SessionManager):
        return run_image_generate(
            session=active_session,
            prompt=prompt,
            model=model_info.id,
            style=style,
            aspect_ratio=ratio,
            image_size=size,
            auto_prompt=not no_enhance,
            output_dir=output,
            download=not no_download,
        )

    if not json_out:
        console.print(f"[dim]Model: {model_info.display_name} (Pool: {router.available_count}/{router.pool_size} · {router.strategy})[/]")
        if style != "auto":
            console.print(f"[dim]Style: {style}[/]")
        if ratio != "auto":
            console.print(f"[dim]Ratio: {ratio}[/]")
        if size != "auto":
            console.print(f"[dim]Size:  {size}[/]")
        console.print()

        with console.status("[bold blue]🎨 Generating image...[/]", spinner="dots"):
            try:
                result = router.run_with_failover(
                    _do_generate,
                    preferred=profile,
                    on_failover=_on_img_failover,
                )
            except GensparkError as e:
                console.print(f"\n[red]Error:[/] {e}")
                sys.exit(1)
            except Exception as e:
                console.print(f"\n[red]Unexpected error:[/] {e}")
                sys.exit(1)

        # Display results
        if result.urls:
            console.print(f"[bold green]✅ Image generated![/]\n")
            for i, url in enumerate(result.urls):
                console.print(f"  [cyan]URL {i + 1}:[/] {url}")
            if result.local_paths:
                console.print()
                for path in result.local_paths:
                    console.print(f"  [green]📁 Saved:[/] {path}")
            if result.refined_prompt:
                console.print(f"\n  [dim]Enhanced prompt: {result.refined_prompt}[/]")
        else:
            console.print("[yellow]⚠️ No images generated.[/]")
    else:
        # JSON output mode
        try:
            result = router.run_with_failover(
                _do_generate,
                preferred=profile,
                on_failover=_on_img_failover,
            )
        except (GensparkError, RuntimeError) as e:
            click.echo(json.dumps({"error": str(e)}, indent=2))
            sys.exit(1)

        output_data = {
            "urls": result.urls,
            "local_paths": result.local_paths,
            "model": result.model,
            "style": result.style,
            "refined_prompt": result.refined_prompt,
            "task_id": result.task_id,
        }
        click.echo(json.dumps(output_data, indent=2, ensure_ascii=False))


@image.command(name="models")
@click.option("--json-output", "--json", "json_out", is_flag=True,
              help="Output as JSON")
def image_models_cmd(json_out):
    """List available image generation models.

    \b
    Examples:
      genspark image models
      genspark image models --json
    """
    from .image_models import list_image_models, DEFAULT_IMAGE_MODEL

    models_list = list_image_models()

    if json_out:
        output = [
            {
                "id": m.id,
                "name": m.display_name,
                "provider": m.provider,
                "max_resolution": m.max_resolution,
                "description": m.description,
            }
            for m in models_list
        ]
        click.echo(json.dumps(output, indent=2))
        return

    table = Table(
        title="🎨 Available Image Generation Models",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("ID", style="green")
    table.add_column("Name", style="white")
    table.add_column("Provider", style="blue")
    table.add_column("Max Res", style="yellow", justify="center")
    table.add_column("Description", style="dim", max_width=50)

    for m in models_list:
        marker = " ★" if m.id == DEFAULT_IMAGE_MODEL else ""
        table.add_row(m.id, m.display_name + marker, m.provider, m.max_resolution, m.description)

    console.print(table)
    console.print(f"\n[dim]★ = default model. Override with --model <id>[/]")
    console.print(f"[dim]Total: {len(models_list)} image models available FREE[/]")


@image.command(name="styles")
@click.option("--search", "-s", default=None, help="Search for styles containing this text")
@click.option("--category", "-c", default=None, help="Filter by category name")
@click.option("--json-output", "--json", "json_out", is_flag=True,
              help="Output as JSON")
def image_styles_cmd(search, category, json_out):
    """List available art styles for image generation.

    Styles are organized by category: Cinema, Photography, Fine Art,
    Digital, 3D & Game Art, and more.

    \b
    Examples:
      genspark image styles
      genspark image styles --search "cyber"
      genspark image styles --category "Cinema"
      genspark image styles --json
    """
    from .image_models import list_styles, ALL_STYLES

    result = list_styles(search=search, category=category)

    if json_out:
        click.echo(json.dumps(result, indent=2, ensure_ascii=False))
        return

    if not result:
        if search:
            console.print(f"[yellow]No styles matching '{search}'[/]")
        elif category:
            console.print(f"[yellow]No category matching '{category}'[/]")
        return

    total = 0
    for cat_name, styles in result.items():
        console.print(f"\n[bold]{cat_name}[/]")
        # Display in columns
        row = []
        for s in styles:
            row.append(s)
            if len(row) == 3:
                console.print(f"  [green]{row[0]:<30}[/] [green]{row[1]:<30}[/] [green]{row[2]}[/]")
                row = []
        if row:
            formatted = "  " + "".join(f"[green]{s:<30}[/]" for s in row)
            console.print(formatted)
        total += len(styles)

    console.print(f"\n[dim]Total: {total} styles shown (of {len(ALL_STYLES)} total)[/]")
    if not search and not category:
        console.print("[dim]Tip: Use --search <term> to filter, e.g., genspark image styles -s cyber[/]")


# ── Integrations Commands ────────────────────────────────────────────────

@main.group()
def integrate():
    """🔗 Generate configs for 3rd party integrations."""
    pass

@integrate.command(name="9router")
def integrate_9router():
    """Print configuration for 9Router integration."""
    console.print(Panel(
        "[bold cyan]9Router Integration Guide[/]\n\n"
        "To set up Genspark CLI as a Free Tier fallback provider in 9Router,\n"
        "enter the following details in your 9Router dashboard:\n\n"
        "  [bold]Provider ID:[/]    [green]genspark-free[/]\n"
        "  [bold]Name:[/]           [green]Genspark CLI[/]\n"
        "  [bold]Base URL:[/]       [green]http://localhost:8080/v1[/]\n"
        "  [bold]API Key:[/]        [green]sk-dummy-token[/]\n\n"
        "[dim]Note: Make sure `genspark server start --port 8080` is running in another terminal![/]",
        title="9Router",
        border_style="green"
    ))

@integrate.command(name="openclaw")
@click.option("--port", "-p", default=8080, help="Genspark proxy port")
@click.option("--host", default="127.0.0.1", help="Genspark proxy host")
@click.option("--apply", "do_apply", is_flag=True, default=False,
              help="Auto-write to ~/.openclaw/openclaw.json")
@click.option("--set-default", "set_default", default=None,
              help="Set a default model (e.g., claude-opus-4-6)")
def integrate_openclaw(port, host, do_apply, set_default):
    """Generate OpenClaw provider configuration for Genspark.

    Creates a complete openclaw.json config that registers Genspark CLI
    as a free LLM provider with all 14 AI models.

    \b
    Prerequisites:
      1. genspark auth login        # Login first
      2. genspark server start      # Start proxy in another terminal

    \b
    Examples:
      genspark integrate openclaw                    # Show config
      genspark integrate openclaw --apply            # Write to ~/.openclaw/
      genspark integrate openclaw --apply --set-default claude-opus-4-6
    """
    from .models import MODELS, DEFAULT_MODEL, to_openclaw_models, to_openclaw_allowlist

    base_url = f"http://{host}:{port}/v1"
    default_model = set_default or DEFAULT_MODEL

    # Build OpenClaw config
    openclaw_config = {
        "models": {
            "mode": "merge",
            "providers": {
                "genspark": {
                    "baseUrl": base_url,
                    "apiKey": "sk-genspark-free",
                    "api": "openai-completions",
                    "models": to_openclaw_models(),
                }
            }
        },
        "agents": {
            "defaults": {
                "model": {
                    "primary": f"genspark/{default_model}",
                },
                "models": to_openclaw_allowlist(),
            }
        }
    }

    config_json = json.dumps(openclaw_config, indent=2, ensure_ascii=False)

    if do_apply:
        openclaw_dir = Path.home() / ".openclaw"
        openclaw_dir.mkdir(parents=True, exist_ok=True)
        config_path = openclaw_dir / "openclaw.json"

        # Merge with existing config if present
        if config_path.exists():
            try:
                existing = json.loads(config_path.read_text())
                # Merge providers
                existing_providers = existing.get("models", {}).get("providers", {})
                existing_providers["genspark"] = openclaw_config["models"]["providers"]["genspark"]
                existing.setdefault("models", {})["providers"] = existing_providers
                existing["models"]["mode"] = "merge"
                # Merge allowlist
                existing_models = existing.get("agents", {}).get("defaults", {}).get("models", {})
                existing_models.update(openclaw_config["agents"]["defaults"]["models"])
                existing.setdefault("agents", {}).setdefault("defaults", {})["models"] = existing_models
                # Set primary model
                existing["agents"]["defaults"]["model"] = openclaw_config["agents"]["defaults"]["model"]
                config_json = json.dumps(existing, indent=2, ensure_ascii=False)
            except (json.JSONDecodeError, OSError):
                pass  # Overwrite if corrupt

        config_path.write_text(config_json)
        console.print(f"[bold green]✅ OpenClaw config written to {config_path}[/]")
        console.print(f"[dim]Default model: genspark/{default_model}[/]")
        console.print()
        console.print("[bold]Next steps:[/]")
        console.print("  1. Start the proxy: [cyan]genspark server start[/]")
        console.print("  2. Apply config:    [cyan]openclaw gateway config.apply[/]")
        console.print(f"  3. Verify:          [cyan]openclaw models list[/]")
    else:
        console.print(Panel(
            f"[bold cyan]OpenClaw Provider Configuration[/]\n\n"
            f"[bold]Base URL:[/]  [green]{base_url}[/]\n"
            f"[bold]API Key:[/]   [green]sk-genspark-free[/] (dummy — auth via cookies)\n"
            f"[bold]Models:[/]    [green]{len(MODELS)}[/] free AI models\n"
            f"[bold]Default:[/]   [green]genspark/{default_model}[/]\n"
            f"[bold]Cost:[/]      [green]$0.00[/] (all models free)\n",
            title="Genspark → OpenClaw",
            border_style="green",
        ))
        console.print("[bold]Config JSON:[/]")
        console.print(config_json)
        console.print()
        console.print("[dim]Run with --apply to write to ~/.openclaw/openclaw.json[/]")
        console.print("[dim]Or copy the JSON above into your openclaw.json manually.[/]")


# ── Multi-Account Pool Commands (`gsk pool`) ─────────────────────────────

@main.group(invoke_without_command=True)
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
@click.pass_context
def pool(ctx, as_json):
    """🔐 Multi-account pool dashboard, routing strategy & health control.

    \b
    Examples:
      gsk pool                          # View pool dashboard
      gsk pool status --json            # JSON pool status
      gsk pool add acc2 acc3            # Add & login multiple accounts
      gsk pool strategy round-robin     # Switch routing strategy
      gsk pool reset                    # Clear cooldown/quota flags
      gsk pool ping                     # Test all accounts concurrently
      gsk pool import work state.json   # Import session state file
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(pool_status, as_json=as_json)


@pool.command(name="status")
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
def pool_status(as_json):
    """Show multi-account pool status, routing strategy, and request metrics."""
    from .account_router import AccountRouter
    from .interactive import _render_pool_table

    pm = get_profile_manager()
    router = AccountRouter(pm)
    statuses = router.get_status()

    if as_json:
        payload = {
            "strategy": router.strategy,
            "max_concurrency_per_account": router.max_concurrency_per_account,
            "pool_size": router.pool_size,
            "available_count": router.available_count,
            "default_profile": pm.default_profile,
            "accounts": statuses,
        }
        click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
        return

    if not statuses:
        console.print("[yellow]No accounts in pool.[/] Add one with: [cyan]gsk auth login[/] or [cyan]gsk pool add <name>[/]")
        return

    console.print(_render_pool_table(router))
    console.print(
        f"\n[dim]Strategy: [cyan]{router.strategy}[/] · "
        f"Available: [green]{router.available_count}/{router.pool_size}[/] · "
        f"Max concurrency/account: [cyan]{router.max_concurrency_per_account}[/][/]"
    )


@pool.command(name="add")
@click.argument("names", nargs=-1, required=True)
def pool_add(names):
    """Add and login one or more account profiles sequentially."""
    from .auth import run_login

    pm = get_profile_manager()
    for name in names:
        try:
            session = pm.get_session(name) if pm._profile_exists(name) else pm.add_profile(name)
        except ValueError as e:
            console.print(f"[red]Error for '{name}':[/] {e}")
            continue

        console.print(Panel(
            f"[bold]🌐 Opening browser to login profile '[cyan]{name}[/]'...[/]\n"
            "1. Log in with your Genspark account\n"
            "2. Send ANY message in the chat so reCAPTCHA token is captured",
            title=f"Pool Add — {name}",
            border_style="cyan",
        ))
        try:
            if run_login(session):
                console.print(f"[bold green]✓ Profile '{name}' added to pool![/]\n")
        except GensparkError as e:
            console.print(f"[red]Login failed for '{name}':[/] {e}\n")


@pool.command(name="strategy")
@click.argument("mode", type=click.Choice(["round-robin", "least-used", "failover"]))
def pool_strategy(mode):
    """Set multi-account routing strategy (round-robin, least-used, failover)."""
    from .account_router import AccountRouter

    pm = get_profile_manager()
    router = AccountRouter(pm)
    router.strategy = mode
    console.print(f"[green]✓[/] Multi-account routing strategy set to [bold cyan]{mode}[/]")


@pool.command(name="reset")
@click.argument("name", required=False, default=None)
def pool_reset(name):
    """Reset cooldown and quota_exhausted state for one or all accounts."""
    from .account_router import AccountRouter

    pm = get_profile_manager()
    router = AccountRouter(pm)
    count = router.reset_cooldowns(name)
    console.print(f"[green]✓[/] Reset cooldown state for [cyan]{count}[/] account(s). Pool available: {router.available_count}/{router.pool_size}")


@pool.command(name="import")
@click.argument("name")
@click.argument("state_file", type=click.Path(exists=True))
@click.option("--token", "-t", default=None, help="Optional reCAPTCHA token string")
def pool_import(name, state_file, token):
    """Import a Playwright storage_state.json into a named account profile."""
    pm = get_profile_manager()
    try:
        state_data = json.loads(Path(state_file).read_text(encoding="utf-8"))
        session = pm.import_profile(name, state_data, recaptcha_token=token)
        console.print(
            f"[green]✓[/] Imported profile [cyan]{name}[/] "
            f"(cookies: {len(session.get_cookies_dict())}, logged_in: {session.is_logged_in})"
        )
    except Exception as e:
        console.print(f"[red]Import failed:[/] {e}")
        sys.exit(1)


@pool.command(name="ping")
@click.option("--model", "-m", default="glm-5.3-flash", help="Lightweight model for health ping")
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
def pool_ping(model, as_json):
    """Ping all logged-in accounts concurrently to verify live readiness."""
    import asyncio
    import time as _time
    from .account_router import AccountRouter
    from .client import GensparkClient

    pm = get_profile_manager()
    router = AccountRouter(pm)
    profiles = [p for p in pm.list_profiles() if p["is_logged_in"]]

    if not profiles:
        if as_json:
            click.echo(json.dumps({"results": []}, indent=2))
        else:
            console.print("[yellow]No logged-in accounts to ping.[/]")
        return

    async def _ping_all():
        async def _ping_one(prof_name: str) -> dict:
            t0 = _time.monotonic()
            sess = pm.get_session(prof_name)
            try:
                async with GensparkClient(sess, model=model, timeout=30.0) as client:
                    resp = await client.chat("Reply with the single word OK.", model=model)
                router.mark_success(prof_name)
                return {
                    "profile": prof_name,
                    "status": "ok",
                    "latency_s": round(_time.monotonic() - t0, 2),
                    "reply": resp.content.strip()[:40],
                }
            except Exception as exc:
                reason = f"{type(exc).__name__}: {exc}".splitlines()[0][:80]
                router.mark_unhealthy(prof_name, reason=reason)
                return {
                    "profile": prof_name,
                    "status": "error",
                    "latency_s": round(_time.monotonic() - t0, 2),
                    "error": reason,
                }

        return list(await asyncio.gather(*(_ping_one(p["name"]) for p in profiles)))

    results = asyncio.run(_ping_all())
    if as_json:
        click.echo(json.dumps({"results": results}, indent=2, ensure_ascii=False))
        return

    table = Table(title="📡 Multi-Account Live Ping", header_style="bold cyan")
    table.add_column("Profile", style="bold")
    table.add_column("Status", justify="center")
    table.add_column("Latency", justify="right")
    table.add_column("Detail")
    for r in results:
        badge = "[green]● OK[/]" if r["status"] == "ok" else "[red]✗ FAIL[/]"
        detail = r.get("reply") if r["status"] == "ok" else r.get("error", "")
        table.add_row(r["profile"], badge, f"{r['latency_s']}s", str(detail))
    console.print(table)


# ── Parallel Batch Command (`gsk batch`) ─────────────────────────────────

@main.command(name="batch")
@click.argument("prompts", nargs=-1)
@click.option("--input-file", "-f", type=click.Path(exists=True), default=None,
              help="Load prompts from .jsonl, .json, or .txt file")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Write results to .jsonl/.json file (or output dir for images)")
@click.option("--model", "-m", default=None, help="Model ID for chat or image batch")
@click.option("--system", "-s", "system_prompt", default=None, help="System prompt for chat batch")
@click.option("--concurrency", "-c", type=int, default=None,
              help="Max concurrent tasks across the account pool")
@click.option("--image", "is_image", is_flag=True, default=False,
              help="Run batch image generation instead of chat")
@click.option("--style", default="auto", help="Image style (when --image is set)")
@click.option("--ratio", default="auto", help="Image aspect ratio (when --image is set)")
@click.option("--size", default="auto", help="Image resolution size (when --image is set)")
@click.option("--no-download", is_flag=True, default=False,
              help="Do not download batch images locally")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit batch summary and results as JSON")
def batch_cmd(
    prompts,
    input_file,
    output,
    model,
    system_prompt,
    concurrency,
    is_image,
    style,
    ratio,
    size,
    no_download,
    as_json,
):
    """⚡ Run multiple chat or image tasks in parallel across all accounts.

    \b
    Examples:
      gsk batch "Summarize X" "Summarize Y" "Summarize Z" -c 3
      gsk batch -f tasks.jsonl -o results.jsonl --concurrency 6
      gsk batch --image "Logo concept A" "Logo concept B" -m flux-2-pro -o ./out
    """
    import asyncio
    from .account_router import AccountRouter
    from .batch import BatchTask, MultiAccountBatchExecutor, load_tasks_from_file

    pm = get_profile_manager()
    router = AccountRouter(pm)

    tasks: list[BatchTask] = []
    if input_file:
        tasks.extend(
            load_tasks_from_file(
                Path(input_file),
                default_model=model,
                system_prompt=system_prompt,
            )
        )
    for idx, p in enumerate(prompts, len(tasks) + 1):
        tasks.append(
            BatchTask(
                id=f"task-{idx}",
                prompt=p,
                model=model,
                system_prompt=system_prompt,
            )
        )

    if not tasks:
        console.print("[red]Error:[/] Provide inline prompts or --input-file <path>.")
        sys.exit(1)

    executor = MultiAccountBatchExecutor(router=router)

    if not as_json:
        mode_str = "Image Generation" if is_image else "Chat"
        console.print(
            f"[bold cyan]⚡ Starting Parallel {mode_str} Batch:[/] "
            f"{len(tasks)} task(s) across {router.available_count}/{router.pool_size} account(s) "
            f"[dim](strategy: {router.strategy})[/]"
        )

    def _progress(res, done: int, total: int) -> None:
        if not as_json:
            icon = "[green]✓[/]" if res.status == "ok" else "[red]✗[/]"
            console.print(
                f"  {icon} [{done}/{total}] [bold]{res.id}[/] via [cyan]{res.profile or '-'}[/] "
                f"({res.elapsed_s}s, attempts: {res.attempts})"
            )

    if is_image:
        out_dir = output if output and not output.endswith((".json", ".jsonl")) else None
        results = asyncio.run(
            executor.execute_image_batch(
                tasks,
                concurrency=concurrency,
                style=style,
                aspect_ratio=ratio,
                image_size=size,
                output_dir=out_dir,
                download=not no_download,
                on_progress=_progress,
            )
        )
    else:
        results = asyncio.run(
            executor.execute_chat_batch(
                tasks,
                concurrency=concurrency,
                on_progress=_progress,
            )
        )

    succeeded = sum(1 for r in results if r.status == "ok")
    summary_payload = {
        "total": len(results),
        "succeeded": succeeded,
        "failed": len(results) - succeeded,
        "strategy": router.strategy,
        "results": [r.to_dict() for r in results],
    }

    if output and (not is_image or output.endswith((".json", ".jsonl"))):
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        if out_path.suffix.lower() == ".json":
            out_path.write_text(json.dumps(summary_payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        else:
            lines = [json.dumps(r.to_dict(), ensure_ascii=False) for r in results]
            out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        if not as_json:
            console.print(f"\n[green]📁 Saved batch output to {out_path}[/]")

    if as_json:
        click.echo(json.dumps(summary_payload, indent=2, ensure_ascii=False))
    else:
        console.print(
            f"\n[bold green]✓ Batch complete:[/] {succeeded}/{len(results)} succeeded."
        )
        if not is_image and not output:
            for r in results:
                if r.status == "ok":
                    console.print(Panel(
                        Markdown(r.content),
                        title=f"[bold]{r.id}[/] · [cyan]{r.profile}[/] · {r.elapsed_s}s",
                        border_style="green",
                    ))
                else:
                    console.print(f"[red]✗ {r.id}:[/] {r.error}")


# ── Configuration Commands (`gsk config`) ────────────────────────────────

CONFIG_KEY_ALIASES = {
    "profile": "default_profile",
    "default_profile": "default_profile",
    "strategy": "routing_strategy",
    "routing_strategy": "routing_strategy",
    "concurrency": "max_concurrency_per_account",
    "max_concurrency": "max_concurrency_per_account",
    "max_concurrency_per_account": "max_concurrency_per_account",
    "model": "default_model",
    "default_model": "default_model",
    "image-model": "default_image_model",
    "image_model": "default_image_model",
    "default_image_model": "default_image_model",
    "cooldown": "default_cooldown_s",
    "default_cooldown_s": "default_cooldown_s",
}


@main.group(name="config", invoke_without_command=True)
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
@click.option("--interactive", "-i", is_flag=True, help="Launch interactive configuration wizard")
@click.pass_context
def config_group(ctx, as_json, interactive):
    """⚙️ Configure default models, multi-account routing strategy & concurrency.

    \b
    Examples:
      gsk config                                # Show current config
      gsk config -i                             # Launch interactive wizard
      gsk config wizard                         # Launch interactive wizard
      gsk config show --json                    # Output config as JSON
      gsk config set strategy round-robin       # Set routing strategy
      gsk config set concurrency 4              # Set max parallel requests/account
      gsk config set model claude-opus-5.5      # Set default chat model
      gsk config set image-model flux-2-pro     # Set default image model
    """
    if ctx.invoked_subcommand is None:
        if interactive:
            ctx.invoke(config_wizard)
        else:
            ctx.invoke(config_show, as_json=as_json)


@config_group.command(name="wizard")
def config_wizard():
    """Interactive step-by-step configuration wizard (Claude Code / Hermes style)."""
    from .image_models import list_image_models, resolve_image_model

    pm = get_profile_manager()
    cfg = pm.get_config()

    console.print(Panel(
        "[bold cyan]✨ Genspark Studio Configuration Wizard[/]\n"
        "[dim]Press Enter at any prompt to keep the current value.[/]",
        border_style="cyan",
    ))

    # 1. Routing Strategy
    strategies = ["round-robin", "least-used", "failover"]
    console.print("\n[bold]1. Multi-Account Routing Strategy:[/]")
    console.print("   [cyan]1[/] · [bold]round-robin[/] (Recommended — rotates across healthy accounts + least-busy)")
    console.print("   [cyan]2[/] · [bold]least-used[/]  (Picks account with lowest total request count & active load)")
    console.print("   [cyan]3[/] · [bold]failover[/]    (Sticks to primary account, fails over on quota/429)")
    strat_choice = click.prompt(
        "   Select strategy (1-3 or name)",
        default=str(cfg.get("routing_strategy", "round-robin")),
        show_default=True,
    ).strip()
    if strat_choice in {"1", "2", "3"}:
        new_strategy = strategies[int(strat_choice) - 1]
    elif strat_choice in strategies:
        new_strategy = strat_choice
    else:
        new_strategy = cfg.get("routing_strategy", "round-robin")

    # 2. Max Concurrency per Account
    console.print("\n[bold]2. Max Parallel Requests per Account:[/]")
    new_conc = click.prompt(
        "   Concurrency per account (1-16)",
        default=int(cfg.get("max_concurrency_per_account", 2)),
        type=int,
        show_default=True,
    )

    # 3. Default Chat Model
    recommended_chat = [
        "claude-opus-5.5",
        "claude-opus-4-7",
        "gpt-6-sol",
        "gemini-3.8-flash",
        "deepseek-v4.1-flash",
        "glm-5.3-flash",
    ]
    console.print("\n[bold]3. Default Chat Model:[/]")
    for idx, mid in enumerate(recommended_chat, 1):
        console.print(f"   [cyan]{idx}[/] · {mid}")
    chat_choice = click.prompt(
        "   Select model (1-6 or any model ID)",
        default=str(cfg.get("default_model", DEFAULT_MODEL)),
        show_default=True,
    ).strip()
    if chat_choice.isdigit() and 1 <= int(chat_choice) <= len(recommended_chat):
        new_model = recommended_chat[int(chat_choice) - 1]
    else:
        try:
            new_model = resolve_model(chat_choice).id
        except ValueError:
            new_model = cfg.get("default_model", DEFAULT_MODEL)

    # 4. Default Image Model
    img_models = [m.id for m in list_image_models()]
    console.print("\n[bold]4. Default Image Generation Model:[/]")
    for idx, mid in enumerate(img_models, 1):
        console.print(f"   [cyan]{idx}[/] · {mid}")
    img_choice = click.prompt(
        f"   Select image model (1-{len(img_models)} or model ID)",
        default=str(cfg.get("default_image_model", "nano-banana-2")),
        show_default=True,
    ).strip()
    if img_choice.isdigit() and 1 <= int(img_choice) <= len(img_models):
        new_img_model = img_models[int(img_choice) - 1]
    else:
        try:
            new_img_model = resolve_image_model(img_choice).id
        except ValueError:
            new_img_model = cfg.get("default_image_model", "nano-banana-2")

    updated = pm.update_config(
        routing_strategy=new_strategy,
        max_concurrency_per_account=max(1, min(32, new_conc)),
        default_model=new_model,
        default_image_model=new_img_model,
    )
    console.print(
        f"\n[bold green]✓ Configuration saved![/] "
        f"(strategy=[cyan]{updated['routing_strategy']}[/], "
        f"concurrency=[cyan]{updated['max_concurrency_per_account']}[/], "
        f"model=[cyan]{updated['default_model']}[/], "
        f"image=[cyan]{updated['default_image_model']}[/])"
    )


@config_group.command(name="show")
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
def config_show(as_json):
    """Display current global configuration."""
    pm = get_profile_manager()
    cfg = pm.get_config()
    if as_json:
        click.echo(json.dumps(cfg, indent=2, ensure_ascii=False))
        return

    table = Table(title="⚙️ Genspark CLI Configuration", header_style="bold cyan")
    table.add_column("Key", style="green")
    table.add_column("Alias", style="dim")
    table.add_column("Value", style="bold white")
    alias_display = {
        "default_profile": "profile",
        "routing_strategy": "strategy",
        "max_concurrency_per_account": "concurrency",
        "default_model": "model",
        "default_image_model": "image-model",
        "default_cooldown_s": "cooldown",
    }
    for k, v in cfg.items():
        if k == "version":
            continue
        table.add_row(k, alias_display.get(k, k), str(v))
    console.print(table)
    console.print(
        "\n[dim]Change any setting with: [cyan]gsk config set <alias> <value>[/] "
        "(e.g. gsk config set strategy round-robin)[/]"
    )


@config_group.command(name="set")
@click.argument("key")
@click.argument("value")
def config_set(key, value):
    """Set a configuration value (strategy, concurrency, model, image-model, profile, cooldown)."""
    from .image_models import resolve_image_model

    pm = get_profile_manager()
    mapped = CONFIG_KEY_ALIASES.get(key.lower().strip())
    if not mapped:
        console.print(
            f"[red]Unknown config key '{key}'.[/] Valid keys: "
            "strategy, concurrency, model, image-model, profile, cooldown"
        )
        sys.exit(1)

    try:
        if mapped == "default_model":
            value = resolve_model(value).id
        elif mapped == "default_image_model":
            value = resolve_image_model(value).id
        updated = pm.update_config(**{mapped: value})
        console.print(f"[green]✓[/] Set [cyan]{mapped}[/] = [bold]{updated[mapped]}[/]")
    except Exception as e:
        console.print(f"[red]Error:[/] {e}")
        sys.exit(1)


@config_group.command(name="reset")
def config_reset():
    """Reset configuration to recommended defaults."""
    pm = get_profile_manager()
    pm.update_config(
        routing_strategy="round-robin",
        max_concurrency_per_account=2,
        default_model=DEFAULT_MODEL,
        default_image_model="nano-banana-2",
        default_cooldown_s=300,
    )
    console.print("[green]✓[/] Configuration reset to defaults.")


# ── Entry Point ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    main()
